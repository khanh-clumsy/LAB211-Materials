
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author admin
 */
public class Number {

    private int base;
    private String number;

    public Number() {
    }

    public Number(int base) throws Exception {
        if (base == 2 || base == 16 || base == 10) {
            this.base = base;
        } else {
            throw new Exception("Base must be 2, 10 or 16!");
        }
    }

    public Number(int base, String number) throws Exception {
        if (base == 2 || base == 16 || base == 10) {
            if (Validate.isValidNumber(base, number)) {
                this.base = base;
                this.number = number;
            } else {
                throw new Exception("Number is invalid with base!");
            }
        } else {
            throw new Exception("Base must be 2, 10 or 16!");
        }
    }

    public int getBase() {
        return base;
    }

    public void setBase(int base) throws Exception {
        if (base == 2 || base == 16 || base == 10) {
            this.base = base;
        } else {
            throw new Exception("Base must be 2, 10 or 16!");
        }
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) throws Exception {
        if (Validate.isValidNumber(this.getBase(), number)) {
            this.number = number;
        } else {
            throw new Exception("Number is invalid with base!");
        }
    }

    public Number toDecimal() throws Exception {
        int decimalValue = 0;
        int length = number.length();
        for (int i = 0; i < length; i++) {
            char digitChar = number.charAt(length - 1 - i);
            int digitValue;
            if (Character.isDigit(digitChar)) {
                digitValue = Character.getNumericValue(digitChar);
            } else if (base == 16 && Character.toUpperCase(digitChar) >= 'A' && Character.toUpperCase(digitChar) <= 'F') {
                digitValue = 10 + (Character.toUpperCase(digitChar) - 'A');
            } else {
                throw new Exception("Invalid number for base " + base);
            }
            decimalValue += digitValue * Math.pow(base, i);
        }
        return new Number(10, String.valueOf(decimalValue));
    }

    public Number change(int otherBase) throws Exception {
        Number decimal = toDecimal();
        int decimalValue = Integer.parseInt(decimal.getNumber());
        StringBuilder newNumber = new StringBuilder();
        while (decimalValue > 0) {
            int remainder = decimalValue % otherBase;
            if (otherBase == 16 && remainder >= 10) {
                newNumber.append((char) (remainder - 10 + 'A'));
            } else {
                newNumber.append(remainder);
            }
            decimalValue /= otherBase;
        }
        newNumber.reverse();
        return new Number(otherBase, newNumber.toString());
    }

    public void input() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            try {
                System.out.print("Nhập base (2, 10, 16): ");
                int base = Integer.parseInt(scanner.nextLine());
                this.setBase(base);
                break;
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }

        while (true) {
            try {
                System.out.print("Nhập số theo base đã chọn: ");
                String number = scanner.nextLine();
                this.setNumber(number);
                break;
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
    }

}
