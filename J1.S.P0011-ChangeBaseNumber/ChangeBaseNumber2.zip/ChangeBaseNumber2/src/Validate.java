/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.util.Scanner;


/**
 *
 * @author admin
 */
public class Validate {

    private static final Scanner SCANNER = new Scanner(System.in);

    public Validate() {

    }

    public int getInt(String msgInfo, String msgErrorOutOfRange, String msgErrorNumber, int min, int max) {
        do {
            try {
                System.out.print(msgInfo);
                int number = Integer.parseInt(SCANNER.nextLine());
                if (number >= min && number <= max) {
                    return number;
                } else {
                    System.out.println(msgErrorOutOfRange);
                }
            } catch (NumberFormatException e) {
                System.out.println(msgErrorNumber);
            }
        } while (true);
    }

    public int getBase(String msgInfo, String baseErrorNumber, String invalidFormatNumber) {
        do {
            try {
                System.out.print(msgInfo);
                int number = Integer.parseInt(SCANNER.nextLine());
                if (number == 2 || number == 10 || number == 16) {
                    return number;
                } else {
                    System.out.println(baseErrorNumber);
                }
            } catch (NumberFormatException e) {
                System.out.println(invalidFormatNumber);
            }
        } while (true);

    }

    public static String getString(String msgInfo, String msgError, int base) {
        do {
            System.out.print(msgInfo);
            String number = SCANNER.nextLine();
            if (Validate.isValidNumber(base, number)) {
                return number;
            } else {
                System.out.println(msgError);
            }
        } while (true);
    }
    public static boolean isValidNumber(int base, String number) {
        switch (base) {
            case 2:
                return number.matches("[01]+");
            case 10:
                return number.matches("[0-9]+");
            case 16:
                return number.matches("[0-9A-F]+");
        }
        return false;
    }
}
