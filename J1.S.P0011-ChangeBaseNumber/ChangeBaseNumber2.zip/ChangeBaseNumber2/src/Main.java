
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Number nb = new Number();
        Number nb2 = new Number();
        try {
            nb.input();
            System.out.println("Input output base: ");
            int baseOutput = sc.nextInt();
            nb2.setBase(baseOutput);
            nb2.setNumber(nb.change(nb2.getBase()).getNumber());
            System.out.println("Number before convert: " + nb.getNumber());
            System.out.println("Result in base " + nb2.getBase() + ": " + nb2.getNumber());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
